
import React from 'react'
import { Container } from 'reactstrap'
import HeroSection from '../components/ui/HeroSection'

import StepSection from '../components/ui/Step-section/StepSection'

const Home = () => {
  return (<>
   <HeroSection/>
 
    <StepSection/>
   
 </>
  )
}

export default Home 